/*
Custom script - @Pier - pierre-delaunay.fr 
*/
jQuery( document ).ready(function() {

	var initDetailDossier = function(){

		//Modal trick
		$('#myModal').on('show.bs.modal', function (e) {
		  $('#myInput').focus();
		})

		//Launch modal onCLick
		$('button.edit').click(function(e){
			$('#myModal').modal();
		});

		//Set style on input selected
		$('div#myModal input[checked]').parent('label').css({
			'color':'#005fab',
			'font-weight': 'bold',
			'background':'url(images/iconRadioOn.jpg) no-repeat 0% 50%',
			'background-size':'22px',
			'padding-left':'50px'
		});

		//On change radio status - add style effect
		$('div#myModal input').change(function(e){
			var myInput = $(this);

			myInput.parent('label').css({
				'color':'#005fab',
				'font-weight': 'bold',
				'background':'url(images/iconRadioOn.jpg) no-repeat 0% 50%',
				'background-size':'22px'
			});			

			//Style change effect for other input
			$('div#myModal input').each(function( index , el) {				  

				if( $(this).attr('checked') ) {
					
					$(this).parent('label').css({
						'color':'rgb(51,51,51)',
						'font-weight': 'normal',
						'background':'url(images/iconRadioOff.jpg) no-repeat 3px 50%',
						'background-size':'14px'
					});
					
					$(this).removeAttr('checked');
				}				  

			});

			myInput.attr('checked','checked');
			
		});

		//Toggle show/hide effect
		$('.iconShow').click(function(e){

			var itemClicked = $(this),
				blockToggleHideShow = itemClicked.parent('h4').next();

			if(blockToggleHideShow.hasClass('hidden')){
				
				blockToggleHideShow.removeClass('hidden');
				itemClicked.css('transform', 'rotate(-90deg)');
				itemClicked.attr('title','Cacher');				

			}else{

				blockToggleHideShow.addClass('hidden');
				itemClicked.css('transform', 'rotate(90deg)');
				itemClicked.attr('title','Voir');				
			}

		});

		//On click pdf
		$('.fileBlock .labelAgent').click(function(e){
			var url = 'pdf/test.pdf';
			window.open(url,'_blank');
		});

		//Effet hover on file line
		$('.fileBlock').hover(function(e){

			var icon = $(this).find('.icon_dl'),
				text = $(this).find('.labelAgent');
			
			icon.css('background','url(images/icon_dl_file_on.jpg) no-repeat 50% 50%');
			text.css({
				'color':'#015fa9',
				'fontWeight':'bold'
			});

		}, function() {
			
			//mouseleave
			var icon = $(this).find('.icon_dl'),
				text = $(this).find('.labelAgent');

			icon.css('background','url(images/icon_dl_file.jpg) no-repeat 50% 50%');
			text.css({
				'color':'#929292',
				'fontWeight':'normal'
			});
		    
	  	});

	};



	var initListeDossier = function(){

		var table = $('table.table').DataTable({
			paginate: false,
			searching: false,
			info: false
	    	//ordering:  false
		});

		$('table thead th').hover(function(e){
			$(this).find('.iconFilterDown').css('border-color','#005ea8 transparent transparent transparent');

		}, function(){			
			$(this).find('.iconFilterDown').css('border-color','#ffffff transparent transparent transparent');
		});
	 		
/*
		var filtreTab = function(itemToFiltre){
			console.log(itemToFiltre.attr('class'));			
			
			table.order([0, 'desc']).draw();		
			table.search( 'Roder' ).draw();	
		}*/

		//Toggle show input to filter tab
		$('span.iconSearch').click(function(event) {
			/* Act on the event */
			$(this).addClass('active');
			$(this).next().removeClass('hidden');
		});

		$('table td').click(function(e){
			var url = 'detailDossier-agent.html';
			window.open(url,'_self');
		});

		$('.iconFilterDown').click(function(e){
			myTriangle = $(this);
			//filtreTab(myTriangle.parent());

			if(myTriangle.hasClass('active')){

				myTriangle.css('transform', 'rotate(0deg)');
				myTriangle.removeClass('active');				

			}else{

				myTriangle.css('transform', 'rotate(180deg)');
				myTriangle.addClass('active');
			}
		});
	}

	var initrecap = function(){


		var isEdit = false;

		//Custom action when click on input field on edit mode
		$('.form-group:not(.file)').one('click',function(e){
			
			var formGrp = $(this);
			var btnOK = $("<div class='okBnt'>OK</div>");

			
			btnOK.click(function(e){						
				
				if(formGrp.hasClass('active')) {

					formGrp.removeClass('active');
					formGrp.css('background','#f1f1f1');					

				}

			});				

			if(isEdit) {								

				formGrp.addClass('active');
				formGrp.css('background','none');
				formGrp.find('div').append(btnOK);				

			}			

		});

		//remove doc
		$('.killPdf').click(function(e){
			$(this).parent().remove();
		});

		//Clic on item pdf on visu mode
		$('form button.inputFileAmeli:not(.more, .select)').on('click',function(e){

			e.preventDefault();
			var url = 'pdf/test.pdf';
			window.open(url,'_blank');

		});

		//Suivant event action
		$('button.suivAmeli').click(function(e){
			if(isEdit) e.preventDefault();
			else $('form').submit();
		});


		//Insert value in input file
		$('form button.more').click(function(e){
			
			//L'autre :
			var allClass = $(this).attr('class');				
			allClass = allClass.split(' ');					
			var number = allClass[3];					
			
			var myBtn = $('<button class="btn btn-primary inputFileAmeli '+number+' hidden">Sélectionnez</button>');	
			var myInput = $('<input type="file" class="form-control inputFileAmeli hiddenAmeli '+number+'" id="inputIdent" placeholder="">');	
			var mySpan = $("<span class='killPdf'>X</span>");

			if(isEdit){						

				$(this).before(myBtn);
				$(this).before(myInput);
				myInput.trigger('click');

				myBtn.on('click',function(e){						
					e.preventDefault();
					var url = 'pdf/test.pdf';
					window.open(url,'_blank');						
				});

				myInput.change(function(){	
					var val;									
					
					if( $(this).val() == '') val = $(this).val();
					else val = 'test.pdf'					

					myBtn.text($(this).val());
					myBtn.append( mySpan );

					myBtn.removeClass('hidden');
				});	

				mySpan.on('click',function(){
					myInput.remove();
					myBtn.remove();
				});

			}
			
		});				

		
		
		$('a.editAmeli').click(function(e){

			var form = $('form.dataForm'),
				editButton = $('a.editAmeli');			
			
			//disable effect link a
			e.preventDefault();	
			
			if(isEdit){
				
				//Toggle class form for css design change
				form.removeClass('edit');
				form.addClass('visu');
				
				//Change button 
				editButton.text('MODIFIER');
				editButton.css({
					'backgroundImage':'url(images/edit_icon.png)',
					'backgroundSize':'14%',
					'backgroundPosition':'10px center'
				});
		
				$('button.suivAmeli').removeClass("disabled");
						
				isEdit = false;	
			
			}else{
			
				
				//Toggle class form for css design change
				form.removeClass('visu');
				form.addClass('edit');

				//Change button 
				editButton.text('ENREGISTRER');
				editButton.css({
					'backgroundImage':'url(images/save.png)',
					'backgroundSize':'12%',
					'backgroundPosition':'10px center'
				});

				$('button.suivAmeli').addClass("disabled");

				isEdit = true;

			}
			
			
		});

		$('form').submit(function(event){
			var form = $(this);
			
			if(isEdit){
				event.preventDefault();				
			} 			

		});


	}

	var initPiecesJointes = function(){

		var getUrlParameter = function getUrlParameter(sParam) {
		    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
		        sURLVariables = sPageURL.split('&'),
		        sParameterName,
		        i;

		    for (i = 0; i < sURLVariables.length; i++) {
		        sParameterName = sURLVariables[i].split('=');

		        if (sParameterName[0] === sParam) {
		            return sParameterName[1] === undefined ? true : sParameterName[1];
		        }
		    }
		};
		
		//Change menu style if other familly member
		var isOther = getUrlParameter('other');
		if(isOther == 1) {

			var item2Stepper = $('div.stepper div.second'),				
				item3Stepper = $('div.stepper div.third');

			item2Stepper.find('span').remove();
			item3Stepper.find('.step').append('<span class="num">3</span>');

			item2Stepper.find('.step').removeClass('active');
			item3Stepper.find('.step').addClass('active');

			item2Stepper.find('.step').addClass('visited');			
		}

		//init modal
		$('#myModal').on('shown.bs.modal', function () {
		  $('#myInput').focus()
		});

		//Modal event button yes
		$('#myModal button.yes').click(function(){
			var checkBoxValueOtherSalarieYes = $('.valueOtherSalarieYes');					
			var buttonYes = $(this);
			var buttonNo = $('#myModal button.no');
			
			//Set value in hidden field
			if(! checkBoxValueOtherSalarieYes.is(':checked')) checkBoxValueOtherSalarieYes.trigger('click');

			//Toggle active button
			buttonYes.addClass('active');
			if(buttonNo.hasClass('active')) buttonNo.removeClass('active');


		});

		//Modal event button no
		$('#myModal button.no').click(function(){
			var buttonNo = $(this);
			var buttonYes = $('#myModal button.yes');
			var checkBoxValueOtherSalarieYes = $('.valueOtherSalarieYes');	

			//Set value in hidden field
			if(checkBoxValueOtherSalarieYes.is(':checked')) checkBoxValueOtherSalarieYes.trigger('click');

			buttonNo.addClass('active');
			if(buttonYes.hasClass('active')) buttonYes.removeClass('active');

		});

		//submit controle
		$('form').submit(function(event){
			var form = $(this);
			var buttonYes = $('#myModal button.yes');
			var buttonNo = $('#myModal button.no');
			
			if(buttonYes.hasClass('active') ){
				form.attr('action', 'accompagnant.html');				
			} 
			else if(buttonNo.hasClass('active')){
				
				form.attr('action', 'recap.html');

				
			}else{
				event.preventDefault();
			}
		});


		$('button.inputFileAmeli.one').click(function(){
			$('input.inputFileAmeli.one').trigger('click');
		});
		$('input.inputFileAmeli.one').change(function(){						
			$('p.specialhelp.one').text( $(this).val() );
		});

		$('button.inputFileAmeli.second').click(function(){
			$('input.inputFileAmeli.second').trigger('click');
		});
		$('input.inputFileAmeli.second').change(function(){						
			$('p.specialhelp.second').text( $(this).val() );
		})

		$('button.inputFileAmeli.third').click(function(){
			$('input.inputFileAmeli.third').trigger('click');
		});
		$('input.inputFileAmeli.third').change(function(){						
			$('p.specialhelp.third').text( $(this).val() );
		});

		$('button.inputFileAmeli.fourth').click(function(){
			$('input.inputFileAmeli.fourth').trigger('click');
		});
		$('input.inputFileAmeli.fourth').change(function(){						
			$('p.specialhelp.fourth').text( $(this).val() );
		});

		$('button.inputFileAmeli.fift').click(function(){
			$('input.inputFileAmeli.fift').trigger('click');
		});
		$('input.inputFileAmeli.fift').change(function(){						
			$('p.specialhelp.fift').text( $(this).val() );
		});

		$('button.inputFileAmeli.sixt').click(function(){
			$('input.inputFileAmeli.sixt').trigger('click');
		});
		$('input.inputFileAmeli.sixt').change(function(){						
			$('p.specialhelp.sixt').text( $(this).val() );
		});

		$('button.inputFileAmeli.sept').click(function(){
			$('input.inputFileAmeli.sept').trigger('click');
		});
		$('input.inputFileAmeli.sept').change(function(){						
			$('p.specialhelp.sept').text( $(this).val() );
		});

		$('button.inputFileAmeli.height').click(function(){
			$('input.inputFileAmeli.height').trigger('click');
		});
		$('input.inputFileAmeli.height').change(function(){						
			$('p.specialhelp.height').text( $(this).val() );
		});

		$('button.inputFileAmeli.nine').click(function(){
			$('input.inputFileAmeli.nine').trigger('click');
		});
		$('input.inputFileAmeli.nine').change(function(){						
			$('p.specialhelp.nine').text( $(this).val() );
		});
		


		//submit controle
		$('.modal-dialog button[type="submit"]').hover(function(){
			var buttonYes = $('#myModal button.yes');
			var buttonNo = $('#myModal button.no');
			var mySubmitButton = $('.modal-dialog button[type="submit"]');

			if(buttonYes.hasClass('active') || buttonNo.hasClass('active')) mySubmitButton.removeClass('notAllowed');
			else mySubmitButton.addClass('notAllowed');

		});
		
	}

	var initInfoSaisie = function(){

		//Active tooltite
		$(function () {
		  $('[data-toggle="tooltip"]').tooltip()
		})

		//Event when select nationalite select
		$('#nationalite').change(function(event){
			valueNationalite = $(this).val();
			var checkotherCountry = $('input[name=otherCountry]');
			
			if( checkotherCountry.is(':checked') ) checkotherCountry.trigger('click');

		});

		//Event when select nationalite select
		$('#ISwork').change(function(event){
			valueWork = $(this).val();

			if(valueWork == 'sansActivite') $('#detailWork').hide();
			else $('#detailWork').show();			
			

			//var checkotherCountry = $('input[name=otherCountry]');			
			//if( checkotherCountry.is(':checked') ) checkotherCountry.trigger('click');

		});

		
		/*
		usefull for later maybe
		$('input[value=langue]').click(function(){
			var hiddentInputAssistant = $(this);
			
			var valueInputAssistant = $('.hiddenValueAssistantLangue');
			valueInputAssistant.trigger('click');
			$('.isPassport').addClass('hidden');

		});

		
		$('input[value=manequin]').click(function(){
			var hiddentInputPassport = $(this);
			var valueInputPassport = $('.hiddenValuePassport');

			valueInputPassport.trigger('click');

			$('.isPassport').addClass('hidden');

		});

		
		$('input[value=passport]').click(function(){
			var hiddentInputMannequin = $(this);
			var valueInputMannequin = $('.hiddenValueManequin');

			valueInputMannequin.trigger('click');

			$('.isPassport').removeClass('hidden');
		});
		*/

		

		//Show hide other country field
		$('input[name=otherCountry]').click(function(event) {
			/* Act on the event */
			var checkotherCountry = $(this);
			var otherCountry = $('#otherCountry');			
			var nationalite = $('#nationalite');			
			
			if( checkotherCountry.is(':checked') ) {
				$("#nationalite option[value=default]").prop('selected', true);
				otherCountry.show();
			}
			else {
				otherCountry.val('');
				otherCountry.hide();
			}

		});

		//Show hide detail work field
		/*$('input[name=detailWork]').click(function(event) {
			
			var checkotherWork = $(this);
			var otherWork = $('#detailWork');	
			var workLess = $('input[name=workLess]');

			otherWork.val('');
			
			if( checkotherWork.is(':checked') ) {
				
				otherWork.show();

				if(workLess.is(':checked')) workLess.trigger('click');
			}
			else {
				otherWork.hide();
			}

		});

		//Show hide detail work field 2
		$('input[name=workLess]').click(function(event){
			var workLess = $(this);
			var detailWork = $('input[name=detailWork]');
			var otherWork = $('#detailWork');	

			if(detailWork.is(':checked')) detailWork.trigger('click');						

		});*/

		//Contrôle email field
		/*function isValidEmailAddress(emailAddress) {
		    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
		    return pattern.test(emailAddress);
		};*/
		
		

	};

	window.init = function() {

		if( $('.container').hasClass('infoSalarie') ) initInfoSaisie();
		if( $('.container').hasClass('piecesJointes') ) initPiecesJointes();
		if( $('.container').hasClass('recap') ) initrecap();
		if( $('.container').hasClass('listeDossier') ) initListeDossier();
		if( $('.container').hasClass('detailDossier') ) initDetailDossier();


		
	}
	
	init(); // true	
});